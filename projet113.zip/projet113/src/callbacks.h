#include <gtk/gtk.h>


void
on_ajGestionCompteAdm_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_ajGestionEmp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajConnect_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajAjoutEmp_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_ajGoToAjoutEmploy_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);








void
on_ajModifEmploy_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajModifEmp_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajSuppEmploy_clicked                (GtkWidget      *button,
                                        gpointer         user_data);

void
on_ajaffaff_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajModifInfoAdm_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajSuppCompteAdm_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajAjoutAdmn_clicked                 (GtkWidget      *button,
                                        gpointer         user_data);

void
on_ajAjoutAdm1_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajGestionCli_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajAjouterCli_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajAjoutCli_clicked                  (GtkWidget      *button,
                                        gpointer         user_data);

void
on_ajModifierCli_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajModifCli_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajSupprimerCli_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajRecherche_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajRechercher_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_aJretour1_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);



void
on_AZretour12_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_mcAjouterVoiture_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_mcSupprimerVoiture_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_mcEnregistrervoiture_clicked        (GtkWidget       *button,
                                        gpointer         user_data);


//FEDIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIi
/*void
on_fgFacture_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_fgDevis_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_fgRetourVersEspace_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_fgButtonRechercheDevis_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_fgButtonSuppDevis_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_fgButtonRechercheFacture_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_fgButtonRechercheFacture1_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_fgRetourVersFacture_clicked         (GtkButton       *button,
                                        gpointer         user_data);*/


void
on_fgDevis_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_fgFacture_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_fgRetourVersEspace_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_jbButtonobtdevis_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_fgButtonSuppDevis_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_fgButtonRechercheDevis1_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_fgButtonRechercheFacture1_clicked   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_fgButtonRechercheDevis_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_fgRetourVersDevis_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_fgButtonRechercheFacture_clicked    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_fgRetourVersFacture_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);
//FINN FEDIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII




void
on_jbButtonchercher_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jbRadiobuttonallsimpl_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jbRadiobuttonallret_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jbButtonobtdevallret_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajchercheCli01_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_jbButtonobtdevis_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jbChercheremplvol_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajGestionService_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_LocationDeVoitureclient_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_AllerALocationDeVoitureAdmin_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_mcBoutonRechercherVoitureClient_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_mcModifierVoiture_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_mcEnregistrervoitureModification_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_mcPrecedent_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_mcPrecedentajoutvoiture_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_mcPrecedentModification_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_BoutonPredecentGestionDeServices_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajRechEmployyy_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajannulationajcli_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajAnnulermodifAge_clicked           (GtkWidget       *button,
                                        gpointer         user_data);





void
on_jbButtongeneredevempl18_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jbObtdevempl12_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jbRadiobuttonemploiallret_clicked   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jbRadiobuttonemploiall_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jbButtonret80_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jbButtonret81_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jbAjoutemplretour_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jbButtonret86_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jbButtonretour90_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);
