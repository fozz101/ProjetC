#include <gtk/gtk.h>


void
on_ajGestionCompteAdm_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_ajGestionEmp_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajConnect_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajAjoutEmp_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_ajGoToAjoutEmploy_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);








void
on_ajModifEmploy_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajModifEmp_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajSuppEmploy_clicked                (GtkWidget      *button,
                                        gpointer         user_data);

void
on_ajaffaff_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

int
on_ajModifInfoAdm_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajSuppCompteAdm_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajAjoutAdmn_clicked                 (GtkWidget      *button,
                                        gpointer         user_data);

void
on_ajAjoutAdm1_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajGestionCli_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajAjouterCli_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajAjoutCli_clicked                  (GtkWidget      *button,
                                        gpointer         user_data);

void
on_ajModifierCli_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajModifCli_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajSupprimerCli_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajRecherche_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajRechercher_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jbButtonchercher_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jbRadiobuttonallret_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jbRadiobuttonallsimpl_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jbButtonobtdevallret_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jbButtonobtdevis_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);
